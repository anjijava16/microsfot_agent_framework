from typing import Dict, Any, List
import os
import logging, warnings
from importlib import import_module
from opentelemetry.sdk.trace.export import SpanExporter, ConsoleSpanExporter
from monocle_apptrace.exporters.exporter_processor import LambdaExportTaskProcessor, is_aws_lambda_environment
from monocle_apptrace.exporters.file_exporter import FileSpanExporter
from monocle_apptrace.exporters.okahu.okahu_exporter import _get_monocle_exporter

logger = logging.getLogger(__name__)

monocle_exporters: Dict[str, Any] = {
    "s3": {"module": "monocle_apptrace.exporters.aws.s3_exporter", "class": "S3SpanExporter"},
    "blob": {"module": "monocle_apptrace.exporters.azure.blob_exporter", "class": "AzureBlobSpanExporter"},
    "okahu": {"module": "monocle_apptrace.exporters.okahu.okahu_exporter", "class": "OkahuSpanExporter"},
    "file": {"module": "monocle_apptrace.exporters.file_exporter", "class": "FileSpanExporter"},
    "memory": {"module": "monocle_apptrace.exporters.base_exporter", "class": "MonocleInMemorySpanExporter"},
    "console": {"module": "opentelemetry.sdk.trace.export", "class": "ConsoleSpanExporter"},
    "otlp": {"module": "opentelemetry.exporter.otlp.proto.http.trace_exporter", "class": "OTLPSpanExporter"},
    "otlp-genai-semconv": {
        "module": "opentelemetry.exporter.otlp.proto.http.trace_exporter",
        "class": "OTLPSpanExporter",
    },
    "gcs" : {"module": "monocle_apptrace.exporters.gcp.gcs_exporter", "class": "GCSSpanExporter"},
    "postgres": {"module": "monocle_apptrace.exporters.postgres.postgres_exporter", "class": "PostgresSpanExporter"},
    "clickhouse": {"module": "monocle_apptrace.exporters.clickhouse.clickhouse_exporter", "class": "ClickHouseSpanExporter"},
    "paygentic": {"module": "monocle_apptrace.exporters.paygentic.paygentic_exporter", "class": "PaygenticSpanExporter"}
}


def get_monocle_exporter_names(exporters_list: str = None) -> List[str]:
    """Resolve configured exporter names without constructing exporters."""
    if exporters_list:
        configured_exporters = exporters_list
    else:
        configured_exporters = _get_monocle_exporter() or "file"
    return [name.strip() for name in configured_exporters.split(",") if name.strip()]


def get_monocle_exporter(exporters_list:str=None) -> List[SpanExporter]:
    exporter_names = get_monocle_exporter_names(exporters_list)
    exporters = []
    
    # Create task processor for AWS Lambda environment
    task_processor = LambdaExportTaskProcessor() if is_aws_lambda_environment() else None

    for exporter_name in exporter_names:
        exporter_name = exporter_name.strip()
        try:
            exporter_class_path = monocle_exporters[exporter_name]
        except KeyError:
            warnings.warn(f"Unsupported Monocle span exporter '{exporter_name}', skipping.")
            continue
        try:
            exporter_module = import_module(exporter_class_path["module"])
            exporter_class = getattr(exporter_module, exporter_class_path["class"])
            # Pass task_processor to all exporters when in AWS Lambda environment
            if task_processor is not None and exporter_module.__name__.startswith("monocle_apptrace"):
                exporters.append(exporter_class(task_processor=task_processor))
            else:
                exporters.append(exporter_class())
        except Exception as ex:
            warnings.warn(
                f"Unable to initialize Monocle span exporter '{exporter_name}', error: {ex}. Using ConsoleSpanExporter as a fallback.")
            exporters.append(ConsoleSpanExporter())
            continue

    # If no exporters were created, default to FileSpanExporter
    if not exporters:
        logger.debug("No valid Monocle span exporters configured. Defaulting to FileSpanExporter.")
        exporters.append(FileSpanExporter())

    # MONOCLE_CONSOLE=true adds ConsoleSpanExporter alongside whatever is configured
    if os.environ.get("MONOCLE_CONSOLE", "").lower() in ("1", "true", "yes"):
        if not any(isinstance(e, ConsoleSpanExporter) for e in exporters):
            exporters.append(ConsoleSpanExporter())
            logger.debug("MONOCLE_CONSOLE is set: added ConsoleSpanExporter.")

    # Note: sensitive-data obfuscation is applied to the span processors that feed
    # these exporters (see install_obfuscation_hooks), so the exporters are returned
    # as-is and callers keep the concrete exporter types they asked for.
    return exporters
