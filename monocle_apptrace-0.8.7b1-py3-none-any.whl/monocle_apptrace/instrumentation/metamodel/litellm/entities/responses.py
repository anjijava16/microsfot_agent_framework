from monocle_apptrace.instrumentation.common.constants import SPAN_TYPES
from monocle_apptrace.instrumentation.metamodel.litellm import (
    _helper,
)
from monocle_apptrace.instrumentation.common.utils import (
    get_error_message,
    resolve_from_alias,
)

# OpenAI Responses API (litellm.responses / aresponses). gpt-5 / o-series
# models route through litellm's raw-httpx response handler, which the
# chat-completion INFERENCE entity does not wrap. Non-streaming only.
RESPONSES = {
    "type": SPAN_TYPES.INFERENCE,
    "subtype": lambda arguments: _helper.responses_inference_type(arguments),
    "attributes": [
        [
            {
                "_comment": "provider type, name, inference_endpoint",
                "attribute": "type",
                "accessor": lambda arguments: "inference."
                + (arguments["kwargs"].get("custom_llm_provider") or "generic"),
            },
            {
                "attribute": "provider_name",
                "accessor": lambda arguments: _helper.extract_provider_name(
                    (arguments["kwargs"].get("litellm_params") or {}).get("api_base")
                ),
            },
            {
                "attribute": "inference_endpoint",
                "accessor": lambda arguments: (
                    arguments["kwargs"].get("litellm_params") or {}
                ).get("api_base"),
            },
        ],
        [
            {
                "_comment": "LLM Model",
                "attribute": "name",
                "accessor": lambda arguments: resolve_from_alias(
                    arguments["kwargs"], ["model"]
                ),
            },
            {
                "attribute": "type",
                "accessor": lambda arguments: "model.llm."
                + resolve_from_alias(arguments["kwargs"], ["model"]),
            },
        ],
    ],
    "events": [
        {
            "name": "data.input",
            "attributes": [
                {
                    "_comment": "this is instruction and user query to LLM",
                    "attribute": "input",
                    "accessor": lambda arguments: _helper.extract_responses_input(
                        arguments["kwargs"]
                    ),
                }
            ],
        },
        {
            "name": "data.output",
            "attributes": [
                {
                    "attribute": "error_code",
                    "accessor": lambda arguments: get_error_message(arguments)
                },
                {
                    "_comment": "this is result from LLM",
                    "attribute": "response",
                    "accessor": lambda arguments: _helper.extract_responses_output(arguments),
                }
            ],
        },
        {
            "name": "metadata",
            "attributes": [
                {
                    "_comment": "this is metadata usage from LLM",
                    "accessor": lambda arguments: _helper.update_span_from_llm_response(
                        arguments["result"]
                    ),
                },
                {
                    "_comment": "finish reason from the Responses API result",
                    "attribute": "finish_reason",
                    "accessor": lambda arguments: _helper.extract_responses_finish_reason(arguments)
                },
                {
                    "_comment": "finish type mapped from finish reason",
                    "attribute": "finish_type",
                    "accessor": lambda arguments: _helper.map_finish_reason_to_finish_type(
                        _helper.extract_responses_finish_reason(arguments))
                }
            ],
        },
    ],
}
